const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

const propertyUnitTableName = 'propertyUnit';

const getPropertyUnitsParams = {
  TableName: propertyUnitTableName
};

const responseHeaders = {
    'Access-Control-Allow-Origin': '*',
};

exports.handler = (event, context, callback) => {
    console.log('Received request for property units ', event);
    
    let propertyId = null;
    let unitId = null;
    
    if (event.queryStringParameters && event.queryStringParameters.propertyId) {
        propertyId = event.queryStringParameters.propertyId;
        
    } else if (event.pathParameters && event.pathParameters.unitId) {
        unitId = event.pathParameters.unitId;
    } else {
        errorResponse({errorMessage: 'missing input'}, 400, context.awsRequestId, callback);
        return; //not sure if this is needed or not
    }
    
    let getMethod;
    if (propertyId) {
        console.log(`getting units for property ${propertyId}`);
        getMethod = () => getAllUnitsForProperty(propertyId);
    } else {
        console.log(`getting unit ${unitId}`);
        getMethod = () => getPropertyUnitById(unitId);
    }
    
    getMethod().then(units => {
        successResponse(units, callback);
    }).catch((error) => {
        errorResponse(error, 500, context.awsRequestId, callback);
    });
};

function getAllUnitsForProperty(propertyId) {
    const queryParams = {
        TableName: propertyUnitTableName,
        FilterExpression:'propertyId = :propertyId',
        ExpressionAttributeValues:{ ":propertyId" : `${propertyId}`}
    };
    
    return ddb.scan(queryParams).promise();
}

function getPropertyUnitById(unitId) {
    return ddb.get({
        TableName : propertyUnitTableName,
        Key: {
            'propertyUnitId': `${unitId}`
        }
    }).promise();
}

function successResponse(data, callback) {
    callback(null, {
        statusCode: 200,
        body: JSON.stringify({
            data
        }),
        headers: responseHeaders
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: responseHeaders
    });
}