const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

const unitTenantTableName = 'unitTenant';

const responseHeaders = {
    'Access-Control-Allow-Origin': '*',
};

exports.handler = (event, context, callback) => {
    console.log('Received request for unit tenants ', event);
    
    let unitId = null;
    let tenantId = null;
    
    if (event.queryStringParameters && event.queryStringParameters.unitId) {
        unitId = event.queryStringParameters.unitId;
        
    } else if (event.pathParameters && event.pathParameters.tenantId) {
        tenantId = event.pathParameters.tenantId;
    } else {
        errorResponse({errorMessage: 'missing input'}, 400, context.awsRequestId, callback);
        return; //not sure if this is needed or not
    }
    
    let getMethod;
    if (unitId) {
        console.log(`getting tenants for unit ${unitId}`);
        getMethod = () => getAllTenantsForUnit(unitId);
    } else {
        console.log(`getting unit tenant ${tenantId}`);
        getMethod = () => getUnitTenantById(tenantId);
    }
    
    getMethod().then(tenants => {
        successResponse(tenants, callback);
    }).catch((error) => {
        errorResponse(error, 500, context.awsRequestId, callback);
    });
};

function getAllTenantsForUnit(unitId) {
    const queryParams = {
        TableName: unitTenantTableName,
        FilterExpression:'propertyUnitId = :unitId',
        ExpressionAttributeValues:{ ":unitId" : `${unitId}`}
    };
    
    return ddb.scan(queryParams).promise();
}

function getUnitTenantById(tenantId) {
    return ddb.get({
        TableName : unitTenantTableName,
        Key: {
            'unitTenantId': `${tenantId}`
        }
    }).promise();
}

function successResponse(data, callback) {
    callback(null, {
        statusCode: 200,
        body: JSON.stringify({
            data
        }),
        headers: responseHeaders
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: responseHeaders
    });
}