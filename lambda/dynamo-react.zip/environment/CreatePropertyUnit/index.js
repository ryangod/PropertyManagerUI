const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    console.log('Received request to create property unit', event);
    
    const requestBody = JSON.parse(event.body);
    
    const unit = {
        propertyUnitId: context.awsRequestId,
        propertyId: requestBody.propertyId,
        unitName: requestBody.unitName,
        beds: +requestBody.beds,
        isOccupied: requestBody.isOccupied,
        value: +requestBody.value
    };
    
    if (!fieldsAreValid(unit)) {
        errorResponse({message: 'Missing required fields'}, 400, context.awsRequestId, callback);
        return;
    }
    
    createProperty(unit).then(() => {
        callback(null, {
            statusCode: 201,
            body: JSON.stringify(unit),
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
        });
    }).catch((err) => {
        errorResponse(err.message, 500, context.awsRequestId, callback)
    });
    
};

function createProperty(unit) {
    return ddb.put({
        TableName: 'propertyUnit',
        Item: {
            ...unit,
            createdOn: new Date().toISOString()
        },
    }).promise();
}

function fieldsAreValid(o) {
    return Object.keys(o).every(function(x) {
        return o[x] !== null && o[x] !== '';
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: {
          'Access-Control-Allow-Origin': '*'
        }
    });
}