const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    console.log('Received request to create lease transaction', event);
    
    const requestBody = JSON.parse(event.body);
    
    const transaction = {
        leaseTransactionId: context.awsRequestId,
        tenantLeaseId: requestBody.tenantLeaseId,
        amountPaid: requestBody.amountPaid,
        paymentMethod: requestBody.paymentMethod,
        transactionDate: new Date().toISOString(),
        transactionStatus: 'Pending'
    };
    
    if (!fieldsAreValid(transaction)) {
        errorResponse({message: 'Missing required fields'}, 400, context.awsRequestId, callback);
        return;
    }
    
    createLeaseTransaction(transaction).then(() => {
        callback(null, {
            statusCode: 201,
            body: JSON.stringify(transaction),
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
        });
    }).catch((err) => {
        errorResponse(err.message, 500, context.awsRequestId, callback);
    });
    
};

function createLeaseTransaction(transaction) {
    return ddb.put({
        TableName: 'leaseTransaction',
        Item: {
            ...transaction,
            createdOn: new Date().toISOString()
        },
    }).promise();
}

function fieldsAreValid(o) {
    return Object.keys(o).every(function(x) {
        return o[x] !== null && o[x] !== '';
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: {
          'Access-Control-Allow-Origin': '*'
        }
    });
}