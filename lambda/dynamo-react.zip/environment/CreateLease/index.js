const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    console.log('Received request to create tenant lease', event);
    
    const requestBody = JSON.parse(event.body);
    
    const lease = {
        tenantLeaseId: context.awsRequestId,
        unitTenantId: requestBody.unitTenantId,
        monthlyCost: requestBody.monthlyCost,
        startDate: requestBody.startDate,
        endDate: requestBody.endDate
    };
    
    if (!fieldsAreValid(lease)) {
        errorResponse({message: 'Missing required fields'}, 400, context.awsRequestId, callback);
        return;
    }
    
    createTenantLease(lease).then(() => {
        callback(null, {
            statusCode: 201,
            body: JSON.stringify(lease),
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
        });
    }).catch((err) => {
        errorResponse(err.message, 500, context.awsRequestId, callback);
    });
    
};

function createTenantLease(lease) {
    return ddb.put({
        TableName: 'tenantLease',
        Item: {
            ...lease,
            createdOn: new Date().toISOString()
        },
    }).promise();
}

function fieldsAreValid(o) {
    return Object.keys(o).every(function(x) {
        return o[x] !== null && o[x] !== '';
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: {
          'Access-Control-Allow-Origin': '*'
        }
    });
}