const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

const leaseTransactionTableName = 'leaseTransaction';

const responseHeaders = {
    'Access-Control-Allow-Origin': '*',
};

exports.handler = (event, context, callback) => {
    console.log('Received request for lease transactions ', event);
    
    let leaseId = null;
    let transactionId = null
    
    if (event.queryStringParameters && event.queryStringParameters.leaseId) {
        leaseId = event.queryStringParameters.leaseId;
        
    } else if (event.pathParameters && event.pathParameters.transactionId) {
        transactionId = event.pathParameters.transactionId;
    } else {
        errorResponse({errorMessage: 'missing input'}, 400, context.awsRequestId, callback);
        return; //not sure if this is needed or not
    }
    
    let getMethod;
    if (leaseId) {
        console.log(`getting transactions for lease ${leaseId}`);
        getMethod = () => getAllTransactionsForLease(leaseId);
    } else {
        console.log(`getting leaseTranaction ${transactionId}`);
        getMethod = () => getLeaseTransactionById(transactionId);
    }
    
    getMethod().then(tenants => {
        successResponse(tenants, callback);
    }).catch((error) => {
        errorResponse(error, 500, context.awsRequestId, callback);
    });
};

function getAllTransactionsForLease(leaseId) {
    const queryParams = {
        TableName: leaseTransactionTableName,
        FilterExpression:'tenantLeaseId = :leaseId',
        ExpressionAttributeValues:{ ":leaseId" : `${leaseId}`}
    };
    
    return ddb.scan(queryParams).promise();
}

function getLeaseTransactionById(leaseId) {
    return ddb.get({
        TableName : leaseTransactionTableName,
        Key: {
            'leaseTransactionId': `${leaseId}`
        }
    }).promise();
}

function successResponse(data, callback) {
    callback(null, {
        statusCode: 200,
        body: JSON.stringify({
            data
        }),
        headers: responseHeaders
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: responseHeaders
    });
}