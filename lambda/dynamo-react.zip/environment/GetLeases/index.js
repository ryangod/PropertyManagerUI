const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

const tenantLeaseTableName = 'tenantLease';

const responseHeaders = {
    'Access-Control-Allow-Origin': '*',
};

exports.handler = (event, context, callback) => {
    console.log('Received request for tenant leases ', event);
    
    let tenantId = null;
    let leaseId = null;
    
    if (event.queryStringParameters && event.queryStringParameters.tenantId) {
        tenantId = event.queryStringParameters.tenantId;
        
    } else if (event.pathParameters && event.pathParameters.leaseId) {
        leaseId = event.pathParameters.leaseId;
    } else {
        errorResponse({errorMessage: 'missing input'}, 400, context.awsRequestId, callback);
        return; //not sure if this is needed or not
    }
    
    let getMethod;
    if (tenantId) {
        console.log(`getting leases for tenant ${tenantId}`);
        getMethod = () => getAllLeasesForTenant(tenantId);
    } else {
        console.log(`getting tenant lease ${leaseId}`);
        getMethod = () => getTenantLeaseById(leaseId);
    }
    
    getMethod().then(tenants => {
        successResponse(tenants, callback);
    }).catch((error) => {
        errorResponse(error, 500, context.awsRequestId, callback);
    });
};

function getAllLeasesForTenant(tenantId) {
    const queryParams = {
        TableName: tenantLeaseTableName,
        FilterExpression:'unitTenantId = :tenantId',
        ExpressionAttributeValues:{ ":tenantId" : `${tenantId}`}
    };
    
    return ddb.scan(queryParams).promise();
}

function getTenantLeaseById(leaseId) {
    return ddb.get({
        TableName : tenantLeaseTableName,
        Key: {
            'tenantLeaseId': `${leaseId}`
        }
    }).promise();
}

function successResponse(data, callback) {
    callback(null, {
        statusCode: 200,
        body: JSON.stringify({
            data
        }),
        headers: responseHeaders
    });
}

function errorResponse(error, responseCode, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: responseCode,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: responseHeaders
    });
}