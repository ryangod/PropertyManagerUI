const AWS = require('aws-sdk');

const ddb = new AWS.DynamoDB.DocumentClient();

const propertyTableName = 'property';

const getAllPropertiesParams = {
  TableName: propertyTableName
};

const responseHeaders = {
    'Access-Control-Allow-Origin': '*',
};

exports.handler = (event, context, callback) => {
    console.log('Received request for properties ', event);
    
    let propertyId;
    if (event.pathParameters) {
        propertyId = event.pathParameters.propertyId;
    } else {
        propertyId = null;
    }
    
    let getMethod;
    if (propertyId) {
        console.log(`getting property ${propertyId}`);
        getMethod = () => getProperty(propertyId);
    } else {
        console.log('getting all properties');
        getMethod = () => getAllProperties();
    }
    
    getMethod().then(properties => {
        successResponse(properties, callback);
    }).catch((error) => {
        errorResponse(error, context.awsRequestId, callback);
    });
};

function getAllProperties() {
    return ddb.scan(getAllPropertiesParams).promise();
}

function getProperty(propertyId) {
    return ddb.get({
        TableName : propertyTableName,
        Key: {
            'propertyId': `${propertyId}`
        }
    }).promise();
}

function successResponse(data, callback) {
    callback(null, {
        statusCode: 200,
        body: JSON.stringify({
            data
        }),
        headers: responseHeaders
    });
}

function errorResponse(error, awsRequestId, callback) {
    console.error(error);
    
    callback(null, {
        statusCode: 500,
        body: JSON.stringify({
          Error: error.errorMessage,
          Reference: awsRequestId,
        }),
        headers: responseHeaders
    });
}